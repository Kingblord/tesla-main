import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import { AuthProvider } from "@/components/auth-provider"
import { Toaster } from "@/components/ui/toaster"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "Tesla Invest - Cryptocurrency Investment Platform",
  description:
    "Invest in Tesla's future with our secure cryptocurrency investment platform. Earn daily returns on your investments.",
  keywords: "Tesla, investment, cryptocurrency, Bitcoin, Ethereum, USDT, daily returns",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <AuthProvider>
          {children}
          <Toaster />
        </AuthProvider>
      </body>
    </html>
  )
}
